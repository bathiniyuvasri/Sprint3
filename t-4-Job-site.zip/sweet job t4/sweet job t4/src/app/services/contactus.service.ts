import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ContactusService {
  _id:any
  api_url: string= "http://localhost:3000/v1/contact/"

  constructor(public http:HttpClient) { }

Contactus (body:string)
{
  let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
  return this.http.post(this.api_url, body, {headers: headers, responseType:'text'});    
} 
getcontactList() {
  let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
  // let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
  return this.http.get(this.api_url, {headers:headers});
}
deleteContact(_id:any) {
  
  let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
  return this.http.delete(this.api_url + _id);
}
}