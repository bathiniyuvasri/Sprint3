import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonService} from "./common.service";
@Injectable({
  providedIn: 'root'
})
export class JobsService {
  
  api_url:string ="http://localhost:3000/v1/job/"
  api_url2:string ="http://localhost:3000/v1/nonuserjob/"  
  base_url:string = "http://localhost:3000/v1/job/percompany/"
  base_url2:string = "http://localhost:3000/v1/application/peruser/"
  url:string = "http://localhost:3000/v1/application/perjob/"
  url2:string = "http://localhost:3000/v1/job/foradmin/"
  jwtToken!: string;
  constructor(private http: HttpClient,public commonService:CommonService) { }
  getAppliedJob(_id:any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.get(this.url+_id,{headers:headers});
  }

  getJobjobseeker() {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.get(this.api_url,{headers:headers});
  }

  getJob() {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.get(this.url2,{headers:headers});
  }
  getJobApplied(emailid:any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.get(this.base_url2+emailid,{headers:headers});
  }
  getJobs2(companyname:any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.get(this.base_url+companyname,{headers:headers});
  }
  getjob3() {
    // this.jwtToken = this.commonService.getJwtToken()
    // let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.get(this.api_url2);
  }
  createJob(body: string) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.post(this.api_url, body, {headers: headers, responseType:'text'});    
  } 
  deleteJob(jobid:any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.delete(this.api_url + jobid,{headers:headers});
  }
  getJobById(jobid:any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.get<any>(this.api_url + jobid,{headers:headers});
  }

  updateJob(body: string, jobid: any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.put(this.api_url + jobid, body, {headers: headers, responseType:'text'});
  }

  deleteJobCompanyname(companyname:any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.delete(this.api_url + companyname,{headers:headers});
  }
}
