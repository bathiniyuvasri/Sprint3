import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonService} from "./common.service";
@Injectable({
  providedIn: 'root'
})
export class JobseekersService {
  apiUrl:string = "http://localhost:5555/jobseekers/"
   baseUrl:string= "http://localhost:3000/v1/job/"
  api_url:string = "http://localhost:3000/v1/user/"
  jwtToken!: string;
  constructor(private http: HttpClient,public commonService:CommonService) { }
  
  registerJobseeker(body: string) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.post(this.api_url, body, {headers: headers, responseType:'text'});
  }

  getJobseekers() {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.get(this.api_url,{headers:headers});
  }
  deleteJobseekers(jobseekerid:any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.delete(this.api_url + jobseekerid,{headers:headers});
  }

  getJobseekersById(jobseekerid:any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.get<any>(this.api_url + jobseekerid,{headers:headers});
  }

  updateJobseekers(body: string, jobseekerid: any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.put(this.api_url + jobseekerid, body, {headers: headers, responseType:'text'});
  }
 

  
  checkValidUser(body: string) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.post(this.api_url + 'login', body, {headers: headers, responseType:'text'});
  }
}