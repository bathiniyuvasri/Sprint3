import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonService} from "./common.service";
@Injectable({
  providedIn: 'root'
})
export class ApplicationService {

  apiUrl:string = "http://localhost:3000/v1/application"
  jwtToken!: string;
  constructor(private http: HttpClient,public commonService:CommonService) { }
  createJobs(body: any) {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.post(this.apiUrl, body, {headers: headers, responseType:'text'});
  }
  getApplicationList() {
    this.jwtToken = this.commonService.getJwtToken()
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    // let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded',"Authorization":this.jwtToken});
    return this.http.get(this.apiUrl, {headers:headers});
  }
}
