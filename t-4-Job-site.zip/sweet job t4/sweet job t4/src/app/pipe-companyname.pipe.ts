import { Pipe, PipeTransform } from '@angular/core';
import { Jobs } from "./jobs"
import { Jobseekers } from './jobseekers';

@Pipe({
  name: 'pipeCompanyname'
})
export class PipeCompanynamePipe implements PipeTransform {

  transform(Jobseekers: Jobseekers[], searchValue:string): Jobseekers[] {

    if (!Jobseekers || !searchValue){
      return Jobseekers;
    }
    return Jobseekers.filter(Jobseekers =>
      Jobseekers.preferredplace.toLocaleLowerCase().includes(searchValue.toLocaleLowerCase()) ||
      Jobseekers.qualification.toLocaleLowerCase().includes(searchValue.toLocaleLowerCase())
      );
  }


}
