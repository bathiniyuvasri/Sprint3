import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployerComponent } from './components/employer/employer.component';
import { JobseekersComponent } from './components/jobseekers/jobseekers.component';
import { EmployerAddjobComponent } from './components/employer-addjob/employer-addjob.component';
import { JobseekersAppComponent } from './components/jobseekers-app/jobseekers-app.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { JobseekersLoginComponent } from './components/jobseekers-login/jobseekers-login.component';
import { EmployerLoginComponent } from './components/employer-login/employer-login.component';
import { EmployeeRegisterComponent } from './components/employee-register/employee-register.component';
import { JobseekerRegisterComponent } from './components/jobseeker-register/jobseeker-register.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
import { JobseekerListComponent } from './components/jobseeker-list/jobseeker-list.component';
import { SearchJobsComponent } from './components/search-jobs/search-jobs.component';
import { AdminComponent } from './components/admin/admin.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { JobseekerUpdateComponent } from './components/jobseeker-update/jobseeker-update.component';
import { AddedEmployeeJoblistComponent } from './components/added-employee-joblist/added-employee-joblist.component';
import { SeekerpasswordComponent } from './components/seekerpassword/seekerpassword.component';
import { EmployerEditComponent } from './components/employer-edit/employer-edit.component';
import { JobsListComponent } from './components/jobs-list/jobs-list.component';
import { UpdateJobsaddedComponent } from './components/update-jobsadded/update-jobsadded.component';
import { SerchHomeComponent } from './components/serch-home/serch-home.component';
import { CvUploadComponent } from './components/cv-upload/cv-upload.component';
import { AdminEmpeditComponent } from './components/admin-empedit/admin-empedit.component';
import { AdminJobseekereditComponent } from './components/admin-jobseekeredit/admin-jobseekeredit.component';
import { AppliedJobComponent } from './components/applied-job/applied-job.component';
import { ApplicationsListComponent } from './components/applications-list/applications-list.component';
import { AppliedJobseekersListComponent } from './components/applied-jobseekers-list/applied-jobseekers-list.component';
import { UpdateJobAdminComponent } from './components/update-job-admin/update-job-admin.component';
import { JobseekerForSearchComponent } from './components/jobseeker-for-search/jobseeker-for-search.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { ContactUsListComponent } from './components/contact-us-list/contact-us-list.component';
import { AboutUsComponent } from './components/about-us/about-us.component';


const routes: Routes = [
  {path:'aboutus', component:AboutUsComponent},
{path:'seekerlogin', component:JobseekersLoginComponent},
{path:'jobposted/:companyname', component:AddedEmployeeJoblistComponent, pathMatch:'full'},
{path:'jobbyemp', component:AddedEmployeeJoblistComponent},
{path:'addjob', component:EmployerAddjobComponent},
{path:'emp', component:EmployerComponent},
{path:'cv', component:CvUploadComponent},
{path:'searchhome', component:SerchHomeComponent},
{path:'joblist', component:JobsListComponent},
{path:'jobseekerupdate/:_id', component:JobseekerUpdateComponent, pathMatch:'full'},
{path:'employerupdate/:_id', component:EmployerEditComponent, pathMatch:'full'},
{path:'adminempupdate/:_id', component:AdminEmpeditComponent, pathMatch:'full'},
{path:'updatejob/:_id', component:UpdateJobsaddedComponent, pathMatch:'full'},
{path:'appliedjobseeker/:_id', component:AppliedJobseekersListComponent, pathMatch:'full'},
{path:'adminseekerupdate/:_id', component:AdminJobseekereditComponent, pathMatch:'full'},
{path:'jobseeker', component:JobseekersComponent},
{path:'emplist', component:EmployeeListComponent},
{path:'jobseekerlist', component:JobseekerListComponent},
{path:'applications', component:ApplicationsListComponent},
{path:'jobapp', component:JobseekersAppComponent},
{path:'search', component:SearchJobsComponent},
{path:'admin', component:AdminComponent},
{path:'adminlogin', component:AdminLoginComponent},
{path:'empregister', component:EmployeeRegisterComponent},
{path:'seekerregister', component:JobseekerRegisterComponent},
{path:'emplogin', component:EmployerLoginComponent},
{path:'seekerpassword', component:SeekerpasswordComponent},
{path:"appliedjob/:emailid", component:AppliedJobComponent},
{path:'updatejobadmin/:_id', component:UpdateJobAdminComponent, pathMatch:'full'},
{path:'jobseekerforsearch', component:JobseekerForSearchComponent},
{path:'contactus', component:ContactUsComponent},
{path:'contactuslist', component:ContactUsListComponent},



{path:'', component:HomePageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
