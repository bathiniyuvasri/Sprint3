import { Jobseekers } from './jobseekers';

describe('Jobseekers', () => {
  it('should create an instance', () => {
    expect(new Jobseekers()).toBeTruthy();
  });
});
