import { PipeQualificationPipe } from './pipe-qualification.pipe';

describe('PipeQualificationPipe', () => {
  it('create an instance', () => {
    const pipe = new PipeQualificationPipe();
    expect(pipe).toBeTruthy();
  });
});
