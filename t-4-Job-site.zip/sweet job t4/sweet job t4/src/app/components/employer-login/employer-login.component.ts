import { Component, OnInit } from '@angular/core';
import { EmployerService } from "./../../services/employer.service";
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from './../../services/common.service';
import {first} from "rxjs/operators";
@Component({
  selector: 'app-employer-login',
  templateUrl: './employer-login.component.html',
  styleUrls: ['./employer-login.component.css']
})
export class EmployerLoginComponent implements OnInit {
  emailid:string = ''
  password:string = ''
  error_message: any;
  constructor(private router: Router, private employerService: EmployerService, public commonService: CommonService) { }

  ngOnInit(): void {
  }

  emplogin = () => {
    //var body = "id=" + this.id 
    var body = "&emailid=" + this.emailid 
        + "&password=" + this.password;
    // let result = {}

    this.employerService.checkValidUser(body)
      .subscribe( (data: string) => {
        console.log('Login Result / JWT Token :')
        console.log(data)
        if(data !== 'Login Failed') {// Login Successful, Got JWT Token
          //localStorage.setItem('loggedin', 'yes');
          // this.commonService.setJwtToken(data);// Store the Token in to CommonService
          // this.commonService.setLoginStatus(1);


          const result = JSON.parse(data)
          this.commonService.setLoginStatus(1);
          this.commonService.set_id(result['_id']);
          this.commonService.setusername(result['username']);
          this.commonService.setemailid(result['emailid']);
          this.commonService.setpassword(result['password']);
          this.commonService.setcompanyname(result['companyname']);
          this.commonService.setpreferredplace(result['preferredplace']);


          // this.commonService.setmobileno(result['mobileno']);
          // this.commonService.setbirthdate(result['birthdate']);
          // this.commonService.setgender(result['gender']);
          // this.commonService.setphoto(result['photo']);
          this.commonService.setJwtToken(result['jwtToken']);

          localStorage.setItem('jwtToken', result['jwtToken']);  
          localStorage.setItem('username', result['username']); 
          localStorage.setItem('emailid', result['emailid']); 
          localStorage.setItem('companyname', result['companyname']);
          localStorage.setItem('preferredplace', result['preferredplace']);  
          // localStorage.setItem('mobileno', result['mobileno']); 
          // localStorage.setItem('birthdate', result['birthdate']); 
          // localStorage.setItem('gender', result['gender']); 
          // localStorage.setItem('photo', result['photo']); 

          this.router.navigate(['emp']);// User Dashboard
        } else {
          this.error_message = data// To Show Error Message in Login Page
          alert("invalid email or password or admin has blocked your account")
        }
      });
  }

  clearMessage() {
    this.error_message = ''
  }
}
