import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SeekerpasswordComponent } from './seekerpassword.component';

describe('SeekerpasswordComponent', () => {
  let component: SeekerpasswordComponent;
  let fixture: ComponentFixture<SeekerpasswordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SeekerpasswordComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SeekerpasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
