import { Component, OnInit } from '@angular/core';
import { CommonService } from './../../services/common.service';
import { Router } from "@angular/router";
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(public commonService:CommonService,private router:Router) { }

  ngOnInit(): void {
  }
  logout() {
    this.commonService.setLoginStatus(0)
    this.commonService.setJwtToken('');// Remove the Token from CommonService
    this.router.navigate(['/']);// Redirect to Home Page
  }
 

}
