import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ContactusService } from "./../../services/contactus.service";

@Component({
  selector: 'app-contact-us-list',
  templateUrl: './contact-us-list.component.html',
  styleUrls: ['./contact-us-list.component.css']
})
export class ContactUsListComponent implements OnInit {

  contacts:any[] = []
  total_no_of_records:any
  message = ''
  constructor( private router: Router, private contactService:ContactusService) {
    console.log('constructor')
    this.getcontactList()
    //this.getUserList() this is not the right place to other methods / still you can do
  }

  ngOnInit(): void {// Life cycle hooks
    console.log('ngOnInit')
    this.getcontactList()
  }

  ngOnDestroy() {
    console.log('ngOnDestroy')
  }

  getcontactList = () => {
    this.contactService.getcontactList().subscribe(
      (result) => {
        this.contacts = <any>result;
        this.total_no_of_records = this.contacts.length
      },
      (error) => {
        // console.log('error')
        // console.log(error)
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        //this.message = error.name
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }

  delete1Contact(contact:any) {
    if(window.confirm(`Are you sure to delete the record with Email Id = ${contact.emailid}?`)) {
      this.contactService.deleteContact(contact._id)
        .subscribe( data => {
          this.contacts = this.contacts.filter(u => u !== contact);// Refresh the users Array / remove the deleted record from Array
        })
    }
  }

  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }
}
