import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminEmpeditComponent } from './admin-empedit.component';

describe('AdminEmpeditComponent', () => {
  let component: AdminEmpeditComponent;
  let fixture: ComponentFixture<AdminEmpeditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminEmpeditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminEmpeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
