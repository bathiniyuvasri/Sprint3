import { Component, OnInit } from '@angular/core';
import { CommonService } from './../../services/common.service';
@Component({
  selector: 'app-employer',
  templateUrl: './employer.component.html',
  styleUrls: ['./employer.component.css']
})
export class EmployerComponent implements OnInit {
  username: any
  emailid: any
  _id:any
  companyname:any
  url:string=''
  constructor(public commonService:CommonService) { }

  ngOnInit(): void {
    this.username = this.commonService.getusername()
  this.emailid = this.commonService.getemailid()
  this._id = this.commonService.get_id()
  this.companyname = this.commonService.getcompanyname()
  this.url = "/jobposted/"+this.companyname
  }
  
}
