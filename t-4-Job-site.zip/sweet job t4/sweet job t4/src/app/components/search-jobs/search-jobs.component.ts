import { Component, OnInit } from '@angular/core';
import { JobsService } from "./../../services/jobs.service";
import { ApplicationService } from "./../../services/application.service";
import { Jobs } from "./../../jobs"
import { Router } from '@angular/router';
import { CommonService } from './../../services/common.service';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-search-jobs',
  templateUrl: './search-jobs.component.html',
  styleUrls: ['./search-jobs.component.css']
})
export class SearchJobsComponent implements OnInit {

  Jobs: any[] = []
  searchValue: any
  username:any
  
  total_no_of_records:any
  message = ''
  emailid: any;
  phoneno1:any;
  phoneno2: any;
  qualification: any;
  experience: any;
  preferredplace: any;
  address: any;
  _id: any;
  date=new Date().getDate()
  month=new Date().getMonth()
  year=new Date().getFullYear()
  time=new Date().getTime()
  hour=new Date().getHours()
  min=new Date().getMinutes()
  sec=new Date().getSeconds()
  constructor(private router: Router,private applicationService:ApplicationService, private jobsService:JobsService,public commonService:CommonService) {
    console.log('constructor')
    this.getJobList()
    //this.getUserList() this is not the right place to other methods / still you can do
   }

  ngOnInit(): void {
    this.username=this.commonService.getusername()
    this.emailid=this.commonService.getemailid()
    this.phoneno1=this.commonService.getphoneno1()
    this.phoneno2=this.commonService.getphoneno2()
    this.qualification=this.commonService.getqualification()
    this.experience=this.commonService.getexperience()
    this.preferredplace=this.commonService.getpreferredplace()
    this.address=this.commonService.getaddress()
    this._id=this.commonService.get_id()

    console.log('ngOnInit')
    console.log(this.phoneno1)
    this.getJobList()
  }
  ngOnDestroy() {
    console.log('ngOnDestroy')
  }
  getJobList = () => {
    this.jobsService.getJobjobseeker().subscribe(
      (result: any) => {
        this.Jobs = <any>result;
        this.total_no_of_records = this.Jobs.length
      },
      (error: any) => {
        // console.log('error')
        // console.log(error)
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        //this.message = error.name
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }


  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }
  // "jobname=" + this.jobname 
  apply = (jobs:any) => { 
    var body =
  "jobid="+ jobs._id
  + "&jobname="+jobs.jobname
  + "&companyname="+jobs.companyname
  + "&jobdescription="+jobs.jobdescription
  + "&minimumexperience="+jobs.minimumexperience
  + "&maximumexperience="+jobs.maximumexperience
  + "&joblocation="+jobs.joblocation
  + "&noticeperiod="+jobs.noticeperiod
  + "&mainskill="+jobs.mainskill
  + "&subskills="+jobs.subskills
  + "&numberofpost="+jobs.jobdescription
  + "&username="+this.username
  + "&emailid="+this.emailid
  + "&phoneno1="+this.phoneno1
  + "&phoneno2="+this.phoneno2
  + "&qualification="+this.qualification
  + "&experience="+this.experience
  + "&preferredplace="+this.preferredplace
  + "&address="+this.address
  + "&useridjobid="+this._id+jobs._id
  + "&datetime="+this.year+'/'+this.month+'/'+this.date+' '+this.hour+':'+this.min+':'+this.sec;


//  username:       {type:String, required:true,  unique:false, trim:true},
//   emailid:        {type:String, required:true,  unique:false, trim:true},// Used to get the list Job Applications for a given Job Seeker
//   phoneno1:       {type:String, required:true,  unique:false, trim:true},
//   phoneno2:       {type:String, required:false, unique:false, trim:true},
//   qualification:  {type:String, required:false, unique:false, trim:true},// B.E., M.B.A., / B.Sc., B.Ed.
//   experience:     {type:String, required:false, unique:false, trim:true},// 0 / 2 / 2.5 / 3.75 years
//   preferredplace: {type:String, required:false, unique:false, trim:true}, // let us keep only one place/city
//   jobname:        {type:String, required:true,  unique:false, trim:true},// Angular Developer / Project Manager
//   companyname:    {type:String, required:true,  unique:false, trim:true},// populate from common service
//   joblocation:    {type:String, required:true,  unique:false, trim:true},// keep only one city Chennai / Bangalore / Hydrabad
//   noticeperiod:   {type:String, required:true,  unique:false, trim:true},// Immediate / urgent / 1 month
//   mainskill:      {type:String, required:true,  unique:false, trim:true},// keep only one skill Angular / Node.js / React.js
//   subskills:      {type:String, required:true,  unique:false, trim:true},// HTML, CSS, JavaScript
//   useridjobid:    {type:String, required:true,  unique:true,  trim:true},// User Id - Job Id. Used to avoid 2nd time application
//   jobid:          {type:String, required:true,  unique:false, trim:true},// Job Id // Used to get the list of Job Seekers those who applied for a given Job Posting
//   datetime:<td>{{job.jobname}}</td>
            // <td>{{job.companyname}}</td>
            // <td>{{job.jobdescription}}</td>
            // <td>{{job.minimumexperience}}</td>
            // <td>{{job.maximumexperience}}</td>
            // <td>{{job.minimumsalary}}</td>
            // <td>{{job.maximumsalary}}</td>
            // <td>{{job.joblocation}}</td>
            // <td>{{job.noticeperiod}}</td>
            // <td>{{job.mainskill}}</td> this.jobService.createJob(body)
      // .subscribe( data => {
      //   console.log("job added successfully!!")
      //   this.router.navigate(['emp']);
      //   alert("job added successfully")
      // },
      // (error) => {
      //   this.message = error.error
      // });    
            // <td>{{job.subskills}}</td>
            if(this.commonService.getNoOfApplications() < this.commonService.getMaxNoOfApplications()) {
              this.applicationService.createJobs(body).subscribe(
                data => {
                  // this.router.navigate(['userlist']);
                  this.commonService.incrementNoOfApplications()//++
                  this.router.navigate(['search']);
                  alert("applied successfully")
                },
                (error) => {
                  this.message = error.error
                  alert("You already applied this job")
                }
              );  
            } else {
              alert('You reached the Maximum No of Application per day, Please try tomorrow.')
            }
        }
}
