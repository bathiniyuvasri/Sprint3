import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployerService } from "./../../services/employer.service";
import { JobsService } from "./../../services/jobs.service";

@Component({
  selector: 'app-applied-jobseekers-list',
  templateUrl: './applied-jobseekers-list.component.html',
  styleUrls: ['./applied-jobseekers-list.component.css']
})
export class AppliedJobseekersListComponent implements OnInit {
  jobs:any[] = []
  total_no_of_records:any
  message = ''
  companyname:any
  _id:any
  reverse=true
  key='datetime'
  constructor(private empService:EmployerService,public jobService:JobsService,private route: ActivatedRoute) { 
    console.log('constructor')
    this.key = 'datetime';
    this.reverse = false;
  }

  ngOnInit(): void {
      this.route.params.subscribe(params => {
        this._id = params['_id'];
        console.log(this._id);
      })
      console.log('ngOnInit')
      this.getJobList(this._id)
    }
  
    ngOnDestroy() {
      console.log('ngOnDestroy')
    }
  
    getJobList = (_id: any) => {
      
      this.jobService.getAppliedJob(this._id).subscribe(
        (result) => {
          this.jobs = <any>result;
          //this.total_no_of_records = this.jobs.length
          this.total_no_of_records = this.jobs.length
          
        },
        (error) => {
          // console.log('error')
          // console.log(error)
          // console.log(error.name)// HttpErrorResponse, if Backend is not running
          //this.message = error.name
          if(error.status === 0 && error.statusText === 'Unknown Error') {
            this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
          } else if(error.status === 200 && error.statusText === 'OK') {
            this.message = error.error.text// JWT Error / Any other error
          }
        }
      );
  
    }
  
  
  
  
    setNegative() {
      this.total_no_of_records = -1
    }
  
    clearMessage() {
      this.message = ''
    }
  }
  

  

