import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobseekerForSearchComponent } from './jobseeker-for-search.component';

describe('JobseekerForSearchComponent', () => {
  let component: JobseekerForSearchComponent;
  let fixture: ComponentFixture<JobseekerForSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JobseekerForSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JobseekerForSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
