import { Component, OnInit } from '@angular/core';
import { JobseekersService } from "./../../services/jobseekers.service";
@Component({
  selector: 'app-jobseeker-for-search',
  templateUrl: './jobseeker-for-search.component.html',
  styleUrls: ['./jobseeker-for-search.component.css']
})
export class JobseekerForSearchComponent implements OnInit {
  jobseekers:any[] = []
  total_no_of_records:any
  searchValue:any
  message = ''
  constructor(private jobseekersService:JobseekersService) { 
    console.log('constructor')
  }

  ngOnInit(): void {// Life cycle hooks
    console.log('ngOnInit')
    this.getJobseekersList()
  }

  ngOnDestroy() {
    console.log('ngOnDestroy')
  }

  getJobseekersList = () => {
    this.jobseekersService.getJobseekers().subscribe(
      (result) => {
        this.jobseekers = <any>result;
        this.total_no_of_records = this.jobseekers.length
      },
      (error) => {
     
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }


  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }

}

