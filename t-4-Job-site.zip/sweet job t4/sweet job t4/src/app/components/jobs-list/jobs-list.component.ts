import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JobsService } from 'src/app/services/jobs.service';
@Component({
  selector: 'app-jobs-list',
  templateUrl: './jobs-list.component.html',
  styleUrls: ['./jobs-list.component.css']
})
export class JobsListComponent implements OnInit {

  job:any[] = []
  total_no_of_records:any
  message = ''
  constructor(private router: Router, private jobsService:JobsService) {
    console.log('constructor')
    this.getJobList()
    //this.getUserList() this is not the right place to other methods / still you can do
   }

  ngOnInit(): void {
    console.log('ngOnInit')
    this.getJobList()
  }
  ngOnDestroy() {
    console.log('ngOnDestroy')
  }
  getJobList = () => {
    this.jobsService.getJob().subscribe(
      (result: any) => {
        this.job = <any>result;
        this.total_no_of_records = this.job.length
      },
      (error: any) => {
        // console.log('error')
        // console.log(error)
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        //this.message = error.name
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }

  delete1Job(job:any) {
    if(window.confirm(`Are you sure to delete the record with job name = ${job.jobname}?`)) {
      this.jobsService.deleteJob(job._id)
        .subscribe( data => {
          this.job = this.job.filter(u => u !== job);// Refresh the users Array / remove the deleted record from Array
        })
    }
  }

  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }

}
