import { Component, OnInit } from '@angular/core';
import { CommonService } from './../../services/common.service';

@Component({
  selector: 'app-jobseekers',
  templateUrl: './jobseekers.component.html',
  styleUrls: ['./jobseekers.component.css']
})
export class JobseekersComponent implements OnInit {
   _id : any;
   emailid:any;
   url:string=''
   username:any;
  constructor(public commonService:CommonService) { }

  ngOnInit(): void {
    this._id = this.commonService.get_id()
    this.emailid = this.commonService.getemailid()
    this.username = this.commonService.getusername()
    this.url = "/appliedjob/"+this.emailid
    

  }
  


}
