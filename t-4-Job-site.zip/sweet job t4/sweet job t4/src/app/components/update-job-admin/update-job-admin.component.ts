import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { JobsService } from 'src/app/services/jobs.service';
import { ActivatedRoute, } from '@angular/router';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-update-job-admin',
  templateUrl: './update-job-admin.component.html',
  styleUrls: ['./update-job-admin.component.css']
})
export class UpdateJobAdminComponent implements OnInit {
 
  jobname:any
  _id:any
  companyname:any
  jobdescription:any
  minimumexperience:any
  maximumexperience:any
  minimumsalary:any
  maximumsalary:any
  joblocation:any
  noticeperiod:any
  mainskill:any
  subskills:any
  numberofpost:any
  message=''
  approved:any
  constructor(private route: ActivatedRoute, private router: Router,private jobsService:JobsService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this._id = params['_id'];
  })
  this.jobsService.getJobById(this._id)
  .subscribe( data1 => {
    console.log(data1)
    this.jobname = data1.jobname;
    this.companyname= data1.companyname;
    this.jobdescription  = data1.jobdescription;
    this.minimumexperience = data1.minimumexperience;
    this.maximumexperience=data1.maximumexperience;
    this.minimumsalary=data1.minimumsalary;
    this.maximumsalary=data1.maximumsalary;
    this.joblocation=data1.joblocation;
    this.noticeperiod=data1.noticeperiod;
    this.mainskill=data1.mainskill;
    this.subskills=data1.subskills;
    this.numberofpost=data1.numberofpost;
    this.approved=data1.approved;
  },
  error => {
    alert(error);
  }
  );
}

editJob() {
var body = "&_id=" + this._id 
    + "&jobname=" + this.jobname
    + "&companyname=" + this.companyname
    + "&jobdescription=" + this.jobdescription 
    + "&minimumexperience=" + this.minimumexperience
    + "&maximumexperience=" + this.maximumexperience
    + "&minimumsalary=" + this.minimumsalary
    + "&maximumsalary=" + this.maximumsalary
    + "&joblocation=" + this.joblocation
    + "&noticeperiod=" + this.noticeperiod
    + "&mainskill=" + this.mainskill
    + "&subskills=" + this.subskills
    + "&numberofpost=" + this.numberofpost
    + "&approved=" + this.approved;

this.jobsService.updateJob(body, this._id)
  .pipe(first())
  .subscribe(
    data => {
      alert("updated successfully")
      this.router.navigate(['admin']);
 
    },
    error => {
      alert(error);
    });
}


}
