import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateJobAdminComponent } from './update-job-admin.component';

describe('UpdateJobAdminComponent', () => {
  let component: UpdateJobAdminComponent;
  let fixture: ComponentFixture<UpdateJobAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateJobAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateJobAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
