import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobseekersAppComponent } from './jobseekers-app.component';

describe('JobseekersAppComponent', () => {
  let component: JobseekersAppComponent;
  let fixture: ComponentFixture<JobseekersAppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JobseekersAppComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JobseekersAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
