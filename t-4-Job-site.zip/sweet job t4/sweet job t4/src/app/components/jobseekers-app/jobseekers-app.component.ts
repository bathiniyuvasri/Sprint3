import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { JobseekersService } from "./../../services/jobseekers.service";
import { ActivatedRoute } from '@angular/router';
import { CommonService } from './../../services/common.service';
import { first } from 'rxjs/operators';
import { ApplicationService } from "./../../services/application.service";
@Component({
  selector: 'app-jobseekers-app',
  templateUrl: './jobseekers-app.component.html',
  styleUrls: ['./jobseekers-app.component.css']
})
export class JobseekersAppComponent implements OnInit {
  username:any
  emailid:any
  phoneno1:any
  phoneno2:any
  qualification:any
  preferredplace:any
  experience:any
  jobname:any
  companyname:any
  joblocation:any
  noticeperiod:any
  mainskill:any
  subskills:any
  useridjobid:any
  jobid:any
  _id:any
 
    constructor(private router:Router, private applicationService:ApplicationService,public commonService:CommonService) { }
  
    ngOnInit(): void {
      // this._id = this.commonService.get_id()
    }
  
  addProfileData = () => {
    var body = 
     "&_id=" + this._id
    +"username=" + this.username
    + "&emailid=" + this.emailid
    + "&phoneno1=" + this.phoneno1
    + "&phoneno2=" + this.phoneno2
    + "&qualification=" + this.qualification 
    + "&experience" + this.experience
    + "&preferredplace=" + this.preferredplace
    + "&jobname=" + this.jobname
    + "&companyname=" + this.companyname
    + "&joblocation=" + this.joblocation
    + "&noticeperiod=" + this.noticeperiod
    + "&mainskill=" + this.mainskill
    + "&subskills=" + this.subskills
    + "&useridjobid=" + this.useridjobid
    + "&jobid=" + this.jobid;
    // + "&pdfSrc=" + this.pdfSrc;
    
  
  this.applicationService.createJobs(body)
  .subscribe( data => {
  this.router.navigate(['cv']);
  alert("Profile data is added successfully!!")
  }
  );
  
  }

}
