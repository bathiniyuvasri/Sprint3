import { Component, OnInit } from '@angular/core';
import { ApplicationService } from "./../../services/application.service";
import { CommonService } from './../../services/common.service';
import { JobseekersService } from "./../../services/jobseekers.service";
@Component({
  selector: 'app-applications-list',
  templateUrl: './applications-list.component.html',
  styleUrls: ['./applications-list.component.css']
})
export class ApplicationsListComponent implements OnInit {

  applications:any[] = []
  user:any[]=[]
  total_no_of_records:any
  phoneno1:any
  phoneno2:any
  useridjobid:any
  message = ''
  constructor(private commonservice:CommonService,private applicationservice:ApplicationService, private jobseekerservice:JobseekersService) { 
    
  }

  ngOnInit(): void {
    this.getapplicationlist()
    this.getjobseekers()
  }
  getjobseekers() {
    this.jobseekerservice.getJobseekers()
  }
  getapplicationlist = () => {
    this.applicationservice.getApplicationList().subscribe(
      (result) => {
        this.applications= <any>result;
        this.total_no_of_records = this.applications.length
      },

      (error) => {
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }
}
