import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { JobsService } from "./../../services/jobs.service";
@Component({
  selector: 'app-employer-addjob',
  templateUrl: './employer-addjob.component.html',
  styleUrls: ['./employer-addjob.component.css']
})
export class EmployerAddjobComponent implements OnInit {
  jobname:any
  companyname:any
  jobdescription:any
  minimumexperience:any
  maximumexperience:any
  minimumsalary:any
  maximumsalary:any
  joblocation:any
  noticeperiod:any
  mainskill:any
  subskills:any
  numberofpost:any
  message=''
  approved:any='false'
  constructor(private http: HttpClient, private router: Router,private jobService:JobsService) { }

  ngOnInit(): void {
  }
  addJob = () => { 
    var body =  "jobname=" + this.jobname 
        + "&companyname=" + this.companyname 
        + "&jobdescription=" + this.jobdescription
        + "&minimumexperience=" + this.minimumexperience
        + "&maximumexperience=" + this.maximumexperience
        + "&minimumsalary=" + this.minimumsalary
        + "&maximumsalary=" + this.maximumsalary
        + "&joblocation=" + this.joblocation
        + "&noticeperiod=" + this.noticeperiod
        + "&mainskill=" + this.mainskill
        + "&subskills=" + this.subskills
        + "&numberofpost=" + this.numberofpost
        + "&approved=" + false;

    this.jobService.createJob(body)
      .subscribe( data => {
        console.log("job added successfully!!")
        this.router.navigate(['emp']);
        alert("job added successfully")
      },
      (error) => {
        this.message = error.error
      });    
  }

  clearMessage() {
    this.message = ''
  }
  
}
