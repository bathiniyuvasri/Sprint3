import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminJobseekereditComponent } from './admin-jobseekeredit.component';

describe('AdminJobseekereditComponent', () => {
  let component: AdminJobseekereditComponent;
  let fixture: ComponentFixture<AdminJobseekereditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminJobseekereditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminJobseekereditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
