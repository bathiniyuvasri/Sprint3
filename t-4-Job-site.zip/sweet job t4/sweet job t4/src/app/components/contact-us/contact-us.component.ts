import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ContactusService } from "./../../services/contactus.service";


@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {
  username: any
  emailid: any
  address: any
  phoneno: any
  subject:any  
  message:string=''
  preferreddatetime:any

  constructor(private router:Router, private contact:ContactusService) { }

  ngOnInit(): void {
  }
  contactUs = () => {
     
    var body = "username=" + this.username 
        + "&emailid=" + this.emailid 
        + "&address=" + this.address
        + "&phoneno=" + this.phoneno
        + "&subject=" + this.subject    
        + "&message=" + this.message
        + "&preferreddatetime=" + this.preferreddatetime;
  
  this.contact.Contactus(body)
      .subscribe( (data: any) => {
        alert('Successfully submitted')
        this.router.navigate(['']);
        
      },
      (error) => {
        this.message = error.error
      });    
  }

  clearMessage() {
    this.message = ''
  }
}

