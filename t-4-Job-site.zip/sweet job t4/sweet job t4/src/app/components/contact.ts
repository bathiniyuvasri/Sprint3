export interface contact {
    _id:  string;
    username: string;
    emailid: string;     
    address: string;     
    phoneno: string;   
    subject: string;      
    message: string;    
    preferreddatetime:String;
  
    }