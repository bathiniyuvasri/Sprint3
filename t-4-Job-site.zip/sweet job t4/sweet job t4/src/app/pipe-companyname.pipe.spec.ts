import { PipeCompanynamePipe } from './pipe-companyname.pipe';

describe('PipeCompanynamePipe', () => {
  it('create an instance', () => {
    const pipe = new PipeCompanynamePipe();
    expect(pipe).toBeTruthy();
  });
});
