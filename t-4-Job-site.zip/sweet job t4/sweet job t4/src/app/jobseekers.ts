export class Jobseekers {
  username:any
  emailid:any
  phoneno1:any
  phoneno2:any
  address:any
  qualification:any
  experience:any
  preferredplace:any

constructor(  username:any,emailid:any,phoneno1:any,phoneno2:any,address:any,qualification:any,experience:any,preferredplace:any){
    this.username = username;
    this.emailid = emailid;
    this.phoneno1 = phoneno1;
    this.phoneno2 = phoneno2;
    this.address = address;
    this.qualification = qualification;
    this.experience = experience;
    this.preferredplace = preferredplace
}
}