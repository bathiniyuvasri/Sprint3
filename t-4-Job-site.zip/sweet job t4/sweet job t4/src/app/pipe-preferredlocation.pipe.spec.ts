import { PipePreferredlocationPipe } from './pipe-preferredlocation.pipe';

describe('PipePreferredlocationPipe', () => {
  it('create an instance', () => {
    const pipe = new PipePreferredlocationPipe();
    expect(pipe).toBeTruthy();
  });
});
