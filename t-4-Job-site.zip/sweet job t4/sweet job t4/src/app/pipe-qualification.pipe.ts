import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipeQualification'
})
export class PipeQualificationPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }

}
