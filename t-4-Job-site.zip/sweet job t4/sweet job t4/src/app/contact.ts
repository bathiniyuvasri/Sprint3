export class Contact {

}

